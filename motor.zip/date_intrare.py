"""Citirea tabelelor de seminar și asocierea după chei."""
from pathlib import Path
import re
import unicodedata
import pandas as pd


def simplifica(text):
    text = unicodedata.normalize("NFKD", str(text).casefold())
    return "".join(c for c in text if not unicodedata.combining(c))


def citeste_csv(cale):
    for codare in ("utf-8-sig", "cp1250"):
        try:
            with Path(cale).open(encoding=codare) as f:
                antet = f.readline()
            sep = max((",", ";", "\t"), key=antet.count)
            df = pd.read_csv(cale, sep=sep, encoding=codare, dtype=str)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise ValueError(f"Codare necunoscută: {cale}")
    df.columns = df.columns.str.strip()
    return df


def coloana(df, variante):
    cautate = {simplifica(c) for c in variante}
    return next((c for c in df if simplifica(c) in cautate), None)


def adauga_cheie(df, auxiliar, stanga, dreapta, campuri):
    chei = auxiliar[dreapta].str.strip().str.casefold()
    if chei.isna().any() or chei.duplicated().any():
        raise ValueError(f"Cheie lipsă sau duplicată în tabelul auxiliar: {dreapta}")
    cautate = df[stanga].str.strip().str.casefold()
    lipsa = ~cautate.isin(chei)
    if lipsa.any():
        raise ValueError(f"Coduri fără corespondent în {dreapta}: {list(cautate[lipsa].unique()[:5])}")
    for tinta, sursa in campuri.items():
        if tinta not in df and sursa:
            df[tinta] = cautate.map(pd.Series(auxiliar[sursa].values, index=chei))


def numere(serie):
    return pd.to_numeric(serie.astype("string").str.strip().str.replace(",", ".", regex=False),
                         errors="raise").astype(float)


def pregateste_date(dosar, principal, auxiliare, necesare):
    df = citeste_csv(dosar / principal)
    cod = coloana(df, ["Siruta", "Code", "CodSiruta", "Indicativ", "Judete"]) or df.columns[0]
    nume = coloana(df, ["DenLocalitate", "Localitate", "City"])
    an = coloana(df, ["Ani", "Anul"])
    valoare = coloana(df, ["Valoare"])
    if an and valoare:
        df[valoare] = numere(df[valoare])
        df[an] = df[an].str.extract(r"(\d{4})", expand=False)
        if df[an].isna().any():
            raise ValueError("An necunoscut în tabelul longitudinal.")
        if cod == "Judete":
            df = df.pivot_table(index=cod, columns=an, values=valoare)
            df = df.fillna(df.mean())
        else:
            df = df.pivot(index=cod, columns=an, values=valoare).fillna(0)
        df = df.reset_index()
    ignorate = {simplifica(c) for c in [cod, nume, "Judet", "County", "Regiune", "Regiunea",
                "Macroregiunea", "MacroRegiune", "Populatie", "Mediu", "Nr_sectie", "IndicativJudet"]}
    indicatori = [c for c in df if simplifica(c) not in ignorate]
    for c in indicatori:
        df[c] = numere(df[c])
    if df[cod].isna().any() or df[cod].duplicated().any():
        raise ValueError(f"Tabelul principal trebuie să aibă un rând pe {cod}.")
    for tinta, variante in [("Judet", ["County", "IndicativJudet"]), ("Regiune", ["Regiunea"]),
                             ("MacroRegiune", ["Macroregiunea"])]:
        sursa = coloana(df, [tinta] + variante)
        if sursa and sursa != tinta:
            df[tinta] = df[sursa]
    for fisier in auxiliare:
        aux = citeste_csv(dosar / fisier)
        cheie = coloana(aux, ["Siruta", "Code", "CodSiruta"])
        if cheie:
            campuri = {"Judet": coloana(aux, ["Judet", "County", "IndicativJudet"]),
                       "Populatie": coloana(aux, ["Populatie"])}
            if not nume:
                campuri["Localitate"] = coloana(aux, ["Localitate", "City", "DenLocalitate"])
            cerute = set(necesare)
            if "Regiune" in cerute and "Regiune" not in df:
                cerute.add("Judet")
            if any(k in cerute and k not in df and v for k,v in campuri.items()):
                adauga_cheie(df, aux, cod, cheie, campuri)
                nume = nume or coloana(df, ["Localitate"])
        elif "Judet" in df and "Regiune" in necesare and "Regiune" not in df:
            cheie = coloana(aux, ["IndicativJudet", "Judet", "County"])
            if cheie and "Regiune" in aux:
                adauga_cheie(df, aux, "Judet", cheie, {"Regiune": "Regiune"})
        if "MacroRegiune" in necesare and "Regiune" in df and "MacroRegiune" not in df:
            macro = coloana(aux, ["MacroRegiune"])
            if macro and "Regiune" in aux:
                adauga_cheie(df, aux, "Regiune", "Regiune", {"MacroRegiune": macro})
    for camp in necesare:
        if camp == "Localitate" and nume:
            continue
        if camp not in df or df[camp].isna().any():
            raise ValueError(f"Lipsește câmpul {camp} sau conține valori lipsă. Verifică data_in.")
    if "Populatie" in df:
        df["Populatie"] = numere(df["Populatie"])
    df = df.set_index(cod)
    return df, indicatori, nume
