"""Controale pe tabelele de intrare și pe rezultatele efectiv scrise de script."""
from operator import eq, ge, gt, le, lt, ne
import numpy as np
import pandas as pd
from date_intrare import pregateste_date, coloana


COMPARA = {"==": eq, "!=": ne, "<": lt, "<=": le, ">": gt, ">=": ge}


def verifica_date(intrari, principal, auxiliare, plan):
    necesare = set()
    for pas in plan:
        necesare.update(pas["necesare"])
    df, _, _ = pregateste_date(intrari, principal, auxiliare, necesare)
    for nr, pas in enumerate(plan, 1):
        p = pas["parametri"]
        coloane = list(p.get("numarator", []))
        if p.get("numitor"):
            coloane.append(p["numitor"])
        coloane.extend(f["camp"] for f in pas.get("filtre", []) if "rezultat" not in f)
        for c in coloane:
            if c not in df or not pd.api.types.is_numeric_dtype(df[c]):
                raise ValueError(f"Cerința {nr}: coloana numerică {c!r} lipsește din date.")
        if p.get("grup") and (p["grup"] not in df or df[p["grup"]].isna().any()):
            raise ValueError(f"Cerința {nr}: gruparea după {p['grup']} nu poate fi aplicată tuturor rândurilor.")
    return df


def verifica_rezultate(intrari, principal, auxiliare, plan, iesiri):
    """Recalculează ratele din datele sursă și verifică cheile și valorile din CSV."""
    df = verifica_date(intrari, principal, auxiliare, plan)
    for nr, pas in enumerate(plan, 1):
        tip = pas["functie"]
        if tip not in {"raport_local", "rata_grupata", "prezenta_vot", "localitate_extrema", "medii_ponderate", "total_grupat", "medie_grupata", "total_local"}:
            continue
        p = pas["parametri"]
        baza = df
        for f in pas.get("filtre", []):
            if "rezultat" not in f:
                baza = baza.loc[COMPARA[f["op"]](baza[f["camp"]], f["prag"])]
        if tip == "prezenta_vot":
            total = baza["Votanti_LP"] + baza["Votanti_LS"]
            valori = (100 * baza["LT"] / total.replace(0, np.nan)).to_frame("Procent")
            if p["prag"] is not None:
                valori = valori.loc[getattr(valori.Procent, p["comparatie"])(p["prag"])]
        elif tip == "localitate_extrema":
            scor = baza[p["numarator"]].sum(axis=1, min_count=1)
            if p["numitor"]:
                scor = scor / baza[p["numitor"]].replace(0, np.nan)
            ordonate = baza.loc[scor.dropna().sort_values(ascending=not p["maxim"], kind="stable").index]
            nume = coloana(baza, ["Localitate", "DenLocalitate", "City"])
            valori = ordonate.drop_duplicates(p["grup"]).set_index(p["grup"])[[nume]].rename(columns={nume:"Localitate"})
        elif tip == "total_local":
            valori = baza[p["indicatori"]].sum(axis=1).to_frame(p["eticheta"])
        elif tip in {"total_grupat", "medie_grupata", "medii_ponderate"}:
            randuri = {}
            for grup, sub in baza.groupby(p["grup"]):
                rand = {}
                for c in p["indicatori"]:
                    x = sub[c].dropna()
                    if tip == "medii_ponderate":
                        w = sub.loc[x.index, p["pondere"]]
                        rand[c] = np.average(x, weights=w) if w.sum() else np.nan
                    else:
                        rand[c] = x.sum() if tip == "total_grupat" else x.mean()
                randuri[grup] = rand
            valori = pd.DataFrame.from_dict(randuri, orient="index").reindex(columns=p["indicatori"]).rename_axis(p["grup"])
        else:
            den = p["numitor"]
            if tip == "raport_local":
                baza = baza.loc[baza[den] != 0]
            num = baza[p["numarator"]]
            divizor = baza[den]
            if tip == "rata_grupata":
                num = num.groupby(baza[p["grup"]]).sum()
                divizor = divizor.groupby(baza[p["grup"]]).sum()
            if not p.get("separat"):
                num = num.sum(axis=1).to_frame(p["eticheta"])
            valori = num.div(divizor.replace(0, np.nan), axis=0) * p["factor"]
        for f in pas.get("filtre", []):
            if "rezultat" in f:
                valori = valori.loc[COMPARA[f["op"]](valori[f["rezultat"]], f["prag"])]
        citit = pd.read_csv(iesiri / (pas["fisier"] + ".csv"), dtype=str, keep_default_na=False)
        cheie = valori.index.name
        if cheie not in citit:
            raise ValueError(f"Cerința {nr}: lipsește cheia de grupare {cheie} din rezultat.")
        citit = citit.set_index(cheie)
        valori.index = valori.index.astype(str)
        if not citit.index.is_unique or set(citit.index) != set(valori.index):
            raise ValueError(f"Cerința {nr}: rândurile CSV nu corespund grupării sau filtrului.")
        if not all(c in citit for c in valori):
            raise ValueError(f"Cerința {nr}: lipsesc coloane din rezultatul ratei.")
        if tip == "localitate_extrema":
            if citit.loc[valori.index, "Localitate"].tolist() != valori.Localitate.tolist():
                raise ValueError(f"Cerința {nr}: localitatea selectată nu corespunde extremului din grup.")
            continue
        actual = citit.loc[valori.index, valori.columns].replace("", np.nan).astype(float)
        if pas.get("zecimale") is not None:
            precizie = pas["zecimale"]
            valori = valori.apply(lambda col: col.map(lambda x: float(f"{x:.{precizie}f}")))
        if not np.allclose(actual, valori, equal_nan=True, rtol=1e-10, atol=1e-12):
            raise ValueError(f"Cerința {nr}: valorile din CSV diferă de recalcularea pe datele sursă.")
