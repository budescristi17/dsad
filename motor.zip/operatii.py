"""Funcții de calcul. Fiecare tabel returnat păstrează cheia pe index."""
import numpy as np
import pandas as pd
from scipy import stats
from scipy.spatial.distance import cdist


def cu_localitate(df, rezultat, nume):
    rezultat = pd.DataFrame(rezultat).copy()
    if nume:
        rezultat.insert(0, nume, df.loc[rezultat.index, nume])
    return rezultat


def total_local(df, indicatori, nume, eticheta):
    return cu_localitate(df, df[indicatori].sum(axis=1).rename(eticheta), nume)


def filtreaza_activitate(df, indicatori, nume):
    x = df[indicatori]
    return cu_localitate(df, x.loc[x.sum(axis=1) > 0], nume)


def procente_locale(df, indicatori, nume):
    x = df[indicatori]
    total = x.sum(axis=1)
    p = x.div(total.where(total != 0), axis=0).mul(100).fillna(0)
    return cu_localitate(df, p, nume)


def raport_local(df, nume, numarator, numitor, factor, eticheta):
    baza = df.loc[df[numitor] > 0]
    raport = baza[numarator].sum(axis=1) * factor / baza[numitor]
    return cu_localitate(df, raport.rename(eticheta), nume)


def rata_grupata(df, grup, numarator, numitor, factor, eticheta, separat):
    total = df.groupby(grup)[list(dict.fromkeys(numarator + [numitor]))].sum()
    baza = total[numitor].replace(0, np.nan)
    if separat:
        return total[numarator].mul(factor).div(baza, axis=0)
    return (total[numarator].sum(axis=1) * factor / baza).rename(eticheta).to_frame()


def localitate_extrema(df, nume, grup, numarator, numitor, maxim):
    baza = df.loc[df[numitor] > 0].copy() if numitor else df.copy()
    scor = baza[numarator].sum(axis=1, min_count=1)
    if numitor:
        scor = scor / baza[numitor]
    grupuri = scor.dropna().groupby(baza[grup])
    pozitii = grupuri.idxmax() if maxim else grupuri.idxmin()
    return baza.loc[pozitii, [grup, nume]].set_index(grup).rename(columns={nume: "Localitate"})


def medii_ponderate(df, indicatori, grup, pondere):
    x = df[indicatori]
    w = df[pondere]
    if (w < 0).any():
        raise ValueError("Ponderile trebuie să fie nenegative.")
    suma = x.mul(w, axis=0).groupby(df[grup]).sum()
    ponderi_valide = x.notna().mul(w, axis=0).groupby(df[grup]).sum()
    return suma / ponderi_valide.replace(0, np.nan)


def total_grupat(df, indicatori, grup):
    return df.groupby(grup)[indicatori].sum()


def medie_grupata(df, indicatori, grup):
    return df.groupby(grup)[indicatori].mean()


def categorie_dominanta(df, indicatori, nume, grup, omite_zero, eticheta, categorie):
    x = df.groupby(grup)[indicatori].sum() if grup else df[indicatori]
    if omite_zero:
        x = x.loc[x.sum(axis=1) > 0]
    rezultat = x.idxmax(axis=1).rename(eticheta).to_frame()
    if categorie:
        rezultat = rezultat.loc[rezultat[eticheta] == categorie]
    return rezultat if grup else cu_localitate(df, rezultat, nume)


def indici_localizare(df, indicatori, grup):
    total = df.groupby(grup)[indicatori + ["Populatie"]].sum()
    pe_activitate = total[indicatori] / total[indicatori].sum().replace(0, np.nan)
    p = total["Populatie"] / total["Populatie"].sum()
    return pe_activitate.div(p.replace(0, np.nan), axis=0)


def prezenta_vot(df, nume, prag, comparatie="gt"):
    inscrisi = df["Votanti_LP"] + df["Votanti_LS"]
    procent = (100 * df["LT"] / inscrisi.replace(0, np.nan)).rename("Procent")
    if prag is not None:
        filtre = {"gt": procent.gt, "ge": procent.ge, "lt": procent.lt, "le": procent.le, "eq": procent.eq}
        procent = procent.loc[filtre[comparatie](prag)]
    return cu_localitate(df, procent, nume)


def tabel_ani(df, indicatori, toti):
    x = df[indicatori]
    return x.loc[x.gt(0).all(axis=1)] if toti else x


def coeficienti_variatie(df, indicatori, grup):
    x = df.groupby(grup)[indicatori]
    return x.std() / x.mean().replace(0, np.nan)


def distributii_teritoriale(df, indicatori, nume, niveluri, procente):
    rezultate = {}
    for nivel in niveluri:
        x = df[indicatori] if nivel == "Localitate" else df.groupby(nivel)[indicatori].sum()
        if procente:
            x = x.div(x.sum(axis=1).replace(0, np.nan), axis=0).mul(100).fillna(0)
        rezultate[nivel] = cu_localitate(df, x, nume) if nivel == "Localitate" else x
    return rezultate


def entropie(p, axa):
    return -(p * np.log2(p.where(p > 0))).sum(axis=axa)


def segregare(df, indicatori, grup, cu_disimilaritate):
    shannon, disimilaritate = {}, {}
    for cheie, parte in df.groupby(grup):
        x = parte[indicatori]
        p = x / x.sum().replace(0, np.nan)
        shannon[cheie] = entropie(p, 0)
        if cu_disimilaritate:
            rest = x.rsub(x.sum(axis=1), axis=0)
            r = rest / rest.sum().replace(0, np.nan)
            disimilaritate[cheie] = (p-r).abs().sum(axis=0, min_count=1) / 2
    h = pd.DataFrame(shannon).T.rename_axis(grup)
    if not cu_disimilaritate:
        return h
    return {"Shannon": h, "Disimilaritate": pd.DataFrame(disimilaritate).T.rename_axis(grup)}


def diversitate(df, indicatori, niveluri):
    rezultate = {}
    for nivel in niveluri:
        x = df.groupby(nivel)[indicatori].sum()
        p = x.div(x.sum(axis=1).replace(0, np.nan), axis=0)
        concentrare = p.pow(2).sum(axis=1, min_count=1)
        rezultate[nivel] = pd.DataFrame({"Shannon": entropie(p, 1), "Simpson": 1-concentrare,
                                         "SimpsonInvers": 1/concentrare})
    return rezultate


def inlocuire_lipsa(df, indicatori):
    x = df[indicatori]
    return x.fillna(x.mean())


def standardizare(df, indicatori, moduri):
    x = inlocuire_lipsa(df, indicatori)
    centrat = x - x.mean()
    rezultat = {}
    if "centrare" in moduri:
        rezultat["x_c"] = centrat
    if "standardizare" in moduri:
        rezultat["x_std"] = centrat / x.std(ddof=0).replace(0, np.nan)
    return rezultat


def matrici_statistice(df, indicatori, grup, moduri):
    x = inlocuire_lipsa(df, indicatori)
    rezultat = {}
    for eticheta, tabel in [("", x)] + (list(x.groupby(df[grup])) if grup else []):
        sufix = "_" + str(eticheta) if eticheta else ""
        if "corelatie" in moduri:
            rezultat["R" + sufix] = tabel.corr().rename_axis("Indicatori")
        if "covarianta" in moduri:
            rezultat["V" + sufix] = tabel.cov().rename_axis("Indicatori")
    return rezultat


def teste_normalitate(df, indicatori):
    x = inlocuire_lipsa(df, indicatori)
    rezultate = {}
    for c in indicatori:
        v = x[c].dropna().to_numpy()
        if len(v) < 3 or np.std(v) == 0:
            rezultate[c] = [np.nan] * 4
            continue
        z = (v - v.mean()) / v.std()
        # Aceeași convenție KS ca la seminar: normala cu parametri estimați.
        ks = stats.kstest(z, "norm").pvalue
        sh = stats.shapiro(v).pvalue
        # Valorile critice Stephens la 5% pentru distribuția normală.
        sortat = np.sort((v-v.mean()) / v.std(ddof=1))
        i = np.arange(1, len(v)+1)
        a2 = -len(v) - np.mean((2*i-1)*(stats.norm.logcdf(sortat)+stats.norm.logsf(sortat[::-1])))
        anderson = a2 < 0.787 / (1 + 4/len(v) - 25/len(v)**2)
        k = min(10, len(v)//5)
        chi = np.nan
        if k >= 4:
            limite = stats.norm.ppf(np.linspace(0, 1, k+1))
            frecvente = np.histogram(z, bins=limite)[0]
            chi = stats.chisquare(frecvente, ddof=2).pvalue > 0.05
        rezultate[c] = [ks > 0.05, sh > 0.05, anderson, chi]
    return pd.DataFrame.from_dict(rezultate, orient="index",
                                  columns=["Kolmogorov-Smirnov", "Shapiro", "Anderson", "Chi2"])


def distante(df, indicatori, moduri):
    x = inlocuire_lipsa(df, indicatori)
    rezultat = {}
    if "euclid" in moduri:
        rezultat["D_Euclid"] = pd.DataFrame(cdist(x, x), x.index, x.index)
    if "mahalanobis" in moduri:
        inversa = np.linalg.pinv(np.atleast_2d(x.cov().to_numpy()), hermitian=True)
        d = cdist(x, x, metric="mahalanobis", VI=inversa)
        rezultat["D_Mahalanobis"] = pd.DataFrame(d, x.index, x.index)
    return rezultat


def inertii(df, indicatori, grup):
    x = inlocuire_lipsa(df, indicatori)
    total = ((x - x.mean())**2).sum().sum()
    abateri = x - x.groupby(df[grup]).transform("mean")
    grupe = abateri.pow(2).sum(axis=1).groupby(df[grup]).sum().rename("Inertie")
    return {"Generala": pd.DataFrame({"Inertie": [total]}, index=["Total"]),
            "Grupe": grupe.to_frame()}


def centri_grupe(df, indicatori, grup):
    return inlocuire_lipsa(df, indicatori).groupby(df[grup]).mean()


def distante_centri(df, indicatori, grup):
    centri = centri_grupe(df, indicatori, grup)
    return pd.DataFrame(cdist(centri, centri), centri.index, centri.index)
