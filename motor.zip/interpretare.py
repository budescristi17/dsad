"""Transformă clasa ML și cuvintele cerinței în parametri expliciți."""
import re
from pathlib import Path
from date_intrare import simplifica
from enunturi import ModelCerinte, separa


def expresii_campuri(coloane):
    sinonime = {
        "totalcifraafaceri": r"cifr\w* (?:totala )?de afaceri",
        "nrsal": r"salariat\w*|angajat\w*|angajare|ocupar\w*",
        "nrfirme": r"firm\w*",
        "totalprofit": r"profit\w*",
        "totalpierdere": r"pierder\w*",
        "populatie": r"populati\w*|locuitor\w*|cap de locuitor",
    }
    echivalente = {
        "cifraafaceri":"totalcifraafaceri", "cifradeafaceri":"totalcifraafaceri",
        "ca":"totalcifraafaceri", "salariati":"nrsal", "angajati":"nrsal",
        "nrangajati":"nrsal", "firme":"nrfirme", "profit":"totalprofit",
        "pierdere":"totalpierdere", "pierderi":"totalpierdere",
    }
    for c in coloane:
        cheie = simplifica(c)
        # «ca» este și conjuncție în română. Înlocuim abrevierea CA înainte de normalizare.
        expresie = r"\b" + re.escape(cheie) + r"\b" if cheie != "ca" else r"(?!)"
        rol = echivalente.get(cheie.replace("_",""), cheie.replace("_",""))
        if rol in sinonime:
            expresie += "|" + sinonime[rol]
        yield c, r"\b(?:" + expresie + r")\b"


def campuri_mentionate(text, coloane):
    gasite = []
    for c, expresie in expresii_campuri(coloane):
        potrivire = re.search(expresie, text)
        if potrivire:
            gasite.append((potrivire.start(), c))
    return [c for _, c in sorted(gasite)]


COMPARATII = {
    ">=": r"cel putin|minimum|minim|mai mar\w* sau egal\w*(?: cu)?|>=|≥",
    "<=": r"cel mult|maximum|maxim|mai mic\w* sau egal\w*(?: cu)?|<=|≤",
    "<": r"sub|mai (?:mic\w*|redus\w*|putin\w*) (?:decat|de)|<",
    ">": r"peste|mai (?:mar\w*|mult\w*) (?:decat|de)|depaseste|>",
    "!=": r"diferit\w* de|!=|≠",
    "==": r"exact|egal\w* cu|==|=",
}
PRAG = "(?P<op>" + "|".join(COMPARATII.values()) + r")\s*(?P<nr>[+-]?\d+(?:[.,]\d+)?)"


def operator_prag(text):
    return next(op for op, model in COMPARATII.items() if re.fullmatch(model, text))


def separa_filtre(text, coloane):
    """Scoate predicatele din formulă, păstrând diferența dintre filtru de rând și de rezultat."""
    filtre = []
    for camp, nume in [("@rezultat", r"\b(?:raport(?:ul)?|rata|rezultatul)\b"), *expresii_campuri(coloane)]:
        if camp != "@rezultat":
            def exista(m):
                filtre.append(dict(camp=camp, op=">", prag=0))
                return " "
            text = re.sub(r"\bunde exista\s+" + nume, exista, text)
            for conditie, op in [(r"pozitiv\w*", ">"), (r"negativ\w*", "<"), (r"nenul\w*", "!="), (r"nul\w*", "==")]:
                def semn(m):
                    filtre.append(dict(camp=camp, op=op, prag=0))
                    return " "
                text = re.sub(nume + r"\s+(?:este\s+|sunt\s+)?" + conditie + r"\b", semn, text)
        for model in (nume + r"\s+(?:(?:este|sunt|de)\s+)?" + PRAG,
                      nume + r"(?=[<>=!≤≥≠])" + PRAG,
                      PRAG + r"\s+(?:de\s+)?" + nume):
            def extrage(m):
                inainte = text[:m.start()]
                if re.search(r"\b(?:judet\w*|regiun\w*)\s+(?:cu|unde|in care)\s*$", inainte) and camp != "@rezultat":
                    raise ValueError("Pentru un filtru pe grup, precizează pragul rezultatului (de exemplu «cu raportul peste 2»).")
                filtre.append(dict(camp=camp, op=operator_prag(m["op"]), prag=float(m["nr"].replace(",", "."))))
                return " "
            text = re.sub(model, extrage, text)
    if filtre and re.search(r"\b(?:sau|ori)\b", text):
        raise ValueError("Filtrul conține alternative. Precizează o singură condiție sau condiții legate prin «și».")
    return text, filtre


def nivel_cerut(t, nivele):
    marcaj = r"\b(?:la nivel(?:ul)?(?: de)?|(?:pentru |in )?fiecare|pe|grupat\w* (?:pe|dupa))\s+"
    explicite = [nivel for nivel, rad in (("Judet","judet"), ("Regiune","regiun"), ("MacroRegiune","macroregiun"))
                 if re.search(marcaj + rad, t)]
    coord = r"(?:judet\w*|regiun\w*|macroregiun\w*|localitat\w*)"
    if re.search(coord + r"\s+(?:si|sau)\s+(?:pe\s+)?" + coord, t):
        raise ValueError("Sunt indicate mai multe niveluri. Cere câte un singur nivel de grupare.")
    if not explicite and re.search(marcaj + "localitat", t):
        return None
    candidati = explicite or [n for n in nivele if n != "Localitate"]
    if len(candidati) > 1:
        raise ValueError("Sunt indicate mai multe niveluri de grupare. Formulează câte o cerință pentru fiecare nivel.")
    return next(iter(candidati), None)


def interpreteaza(text, antet, tip, indicatori, numar, categorie):
    nume_csv = re.findall(r"(?i)([\w-]+\.csv)\b", text)
    fara_fisiere = re.sub(r"(?i)[\w-]+\.csv\b", " ", text)
    t = simplifica(re.sub(r"\bCA\b", "cifra de afaceri", fara_fisiere))
    iesire = nume_csv[0] if nume_csv else f"Cerinta{numar}.csv"
    if tip == "medii_ponderate" and not nume_csv and "cifra de afaceri" in t:
        iesire = f"Output{numar}.csv"
    param = {}
    necesare = set()
    filtre = []
    verificabile = {"raport_local", "rata_grupata", "localitate_extrema", "total_grupat", "total_local",
                    "medii_ponderate", "medie_grupata"}
    if tip in verificabile:
        t, filtre = separa_filtre(t, indicatori + ["Populatie"])
        if re.search(PRAG, t):
            raise ValueError("Nu pot asocia pragul cu o coloană. Scrie, de exemplu, «Angajati >= 5» sau «raportul > 2».")
        ramas = re.sub(r"\bsi\b(?=\s*[,.;)]|\s*$)", " ", t)
        if tip in {"rata_grupata", "raport_local"} and re.search(r"\b(?:unde|doar daca|cu conditia ca|numai daca)\s+\w", ramas):
            raise ValueError("Condiția de filtrare nu este suficient de clară. Scrie coloana, operatorul și pragul numeric.")
        if tip in {"rata_grupata", "raport_local"} and re.search(r"\b(?:din judetul|din regiunea|(?:din|in) mediul)\s+\w+", t):
            raise ValueError("Filtrul geografic pe o valoare nominală nu este acceptat. Selectează acele rânduri în CSV înainte de calcul.")
        necesare.update(f["camp"] for f in filtre if f["camp"] != "@rezultat")
    nivele = [k for k, s in [("Localitate","localitat"), ("Judet","judet"),
              ("Regiune",r"\bregiun"), ("MacroRegiune","macroregiun")] if re.search(s,t)]
    grup = next((n for n in reversed(nivele) if n != "Localitate"), None)
    if tip in verificabile:
        grup = nivel_cerut(t, nivele)
        if tip in {"rata_grupata", "raport_local"}:
            if not grup and "Localitate" not in nivele and not re.search(r"\bpe rand\b", t):
                raise ValueError("Precizează nivelul raportului: pe localitate, județ sau regiune.")
            tip = "rata_grupata" if grup else "raport_local"
    sortare = "desc" if "descresc" in t else ("asc" if re.search(r"\bcrescat", t) else "")
    etichete = [x.strip() for x in antet.split(",")] if antet else []
    def eticheta(implicit):
        return etichete[-1] if len(etichete) in (2, 3) else implicit

    def cere_grup():
        if not grup:
            raise ValueError(f"Specifică nivelul (județ, regiune sau macroregiune): {text}")
        param["grup"] = grup
        necesare.add(grup)

    mentionate = campuri_mentionate(t, indicatori + ["Populatie"])
    selectate = [c for c in mentionate if c in indicatori]
    if tip in ("rata_grupata", "raport_local", "localitate_extrema"):
        # Caută numitorul după expresia de împărțire înainte de a aplica ordinea mențiunilor.
        separare = re.search(r"(?:\bpe (?:cap de )?(?=locuitor|salariat)|\bper |\bla (?:\d+ (?:de )?|mia de )?(?=locuitor)|\braportat\w* la |\bimpart\w* la |/)", t)
        numitor = None
        specific = None
        if separare:
            operand = re.split(r"[,;().]|\b(?:si sa|pentru|unde|sortat\w*|la nivel|pe judet|pe regiun|in fiecare)\b",
                               t[separare.end():], maxsplit=1)[0]
            dupa = campuri_mentionate(operand, indicatori + ["Populatie"])
            if len(dupa) != 1:
                raise ValueError("Numitorul este absent sau ambiguu. Precizează o singură coloană după împărțire.")
            numitor = dupa[0] if dupa else None
            if separare.group() == "/":
                lhs = re.split(r"[;,.]|\b(?:calculeaza|determina)\b", t[:separare.start()])[-1]
                specific = campuri_mentionate(lhs, indicatori + ["Populatie"])
                if len(specific) != 1 or numitor in specific or re.search(r"[/+*]", operand):
                    raise ValueError("Formula trebuie să indice un numărător și un numitor simplu, fără alți operanzi.")
        else:
            pereche = re.search(r"\braport(?:ul)? (?:dintre|intre) (.+?) si (.+)", t)
            if pereche:
                rhs = re.split(r"[,;().]|\b(?:pentru|unde|pe judet\w*|pe regiun\w*|in fiecare|la nivel|salveaza)\b", pereche[2], maxsplit=1)[0]
                st = campuri_mentionate(pereche[1], indicatori + ["Populatie"])
                dr = campuri_mentionate(rhs, indicatori + ["Populatie"])
                if len(st) != 1 or len(dr) != 1 or st == dr:
                    raise ValueError("Raportul trebuie să indice două coloane distincte. Scrie «numărător / numitor».")
                numitor = dr[0]
                specific = st
        if not numitor and len(mentionate) > 2:
            raise ValueError("Mai multe coloane pot fi numitor. Scrie explicit «numărător / numitor».")
        if not numitor and len(mentionate) == 2:
            numitor = mentionate[1]
        if not numitor and ("populati" in t and tip == "rata_grupata"):
            numitor = "Populatie"
        if not numitor and tip != "localitate_extrema":
            raise ValueError(f"Nu pot identifica numitorul. Scrie explicit coloanele: {text}")
        numarator = specific or [c for c in mentionate if c != numitor]
        if not numarator:
            if not re.search(r"activitat|industr|innoptari|toate|totalul indicatorilor", t):
                raise ValueError(f"Nu pot identifica numărătorul: {text}")
            numarator = indicatori
        if numitor:
            necesare.add(numitor)
        necesare.update(numarator)
        param.update(numarator=numarator, numitor=numitor)
        if tip != "raport_local":
            cere_grup()
        if tip == "localitate_extrema":
            param["maxim"] = not re.search(r"minim|mai mic|mai redus|mai putin|mai scazut", t)
            necesare.add("Localitate")
        else:
            baza = re.search(r"\bla\s+([\d. ]+?)\s*(?:de\s+)?locuitor", t)
            factor = int(re.sub(r"\D", "", baza[1])) if baza else 1
            if re.search(r"\b(mia|o mie) de locuitor", t):
                factor = 1000
            if "procent" in t or "%" in t:
                factor = 100
            implicit = "Rata Ocuparii" if "ocupar" in t else "Raport"
            if "cifra de afaceri" in t and numitor == "NrSal":
                implicit = "Raport CA/NrSal"
            elif "cifra de afaceri" in t and numitor == "Populatie":
                implicit = "CA/Loc"
            param.update(factor=factor, eticheta=eticheta(implicit))
            if tip == "rata_grupata":
                param["separat"] = bool(re.search(r"pe fiecare an|pe fiecare activitate", t))
    elif tip == "medii_ponderate":
        cere_grup()
        dupa = re.split(r"folosind ca pondere|ponderat\w* (?:cu|dupa)|ponderi(?:le)? (?:sunt|date de)", t)
        ponderi = campuri_mentionate(dupa[-1], indicatori + ["Populatie"])
        if not ponderi:
            raise ValueError("Precizează ponderea, de exemplu «folosind ca pondere populația».")
        pondere = ponderi[0] if len(dupa) > 1 else ponderi[-1]
        necesare.add(pondere)
        param.update(pondere=pondere, indicatori=[c for c in selectate if c != pondere] or indicatori)
    elif tip in ("medie_grupata", "total_grupat", "indici_localizare", "coeficienti_variatie"):
        cere_grup()
        param["indicatori"] = selectate or indicatori
        if tip == "indici_localizare":
            necesare.add("Populatie")
    elif tip in ("distributii_teritoriale", "diversitate"):
        if not nivele:
            raise ValueError("Precizează nivelurile teritoriale.")
        param["niveluri"] = nivele
        necesare.update(nivele)
        if tip == "distributii_teritoriale":
            param["procente"] = bool(re.search(r"procent|ponder", t))
    elif tip == "segregare":
        cere_grup()
        param["cu_disimilaritate"] = "disimil" in t or "segreg" in t
        if "vot" in t:
            param["indicatori"] = [c for c in indicatori if c.startswith(("Barbati_", "Femei_"))]
    elif tip == "categorie_dominanta":
        param["grup"] = grup
        if grup:
            necesare.add(grup)
        varste = [c for c in indicatori if c.startswith(("Barbati_", "Femei_"))]
        if varste:
            param["indicatori"] = varste
        filtru = next((c for c in varste if simplifica(c) in t), None)
        if "categorie_varsta" in t or iesire.casefold() == "categorie_varsta.csv":
            if not categorie and not filtru:
                raise ValueError("Tema cere o categorie. Specifică, de exemplu, Barbati_35-44.")
            filtru = filtru or categorie
        if filtru and filtru not in varste:
            raise ValueError(f"Categorie indisponibilă: {filtru}. Opțiuni: {varste}")
        if iesire.casefold() == "categorie_varsta.csv":
            iesire = filtru + ".csv"
        param.update(categorie=filtru, omite_zero="omise" in t or "fara activitate" in t,
                     eticheta=eticheta("Categorie" if varste else ("Anul" if "anul" in t else "Activitate")))
        if "anul" in t and not grup:
            necesare.add("Localitate")
    elif tip == "prezenta_vot":
        param["comparatie"] = "gt"
        prag = re.search(r"(\d+(?:[.,]\d+)?)\s*%", t)
        param["prag"] = float(prag[1].replace(",", ".")) if prag else None
        if prag:
            conditii = {"ge": r"cel putin|minimum|minim|>=|≥", "le": r"cel mult|maximum|maxim|<=|≤",
                        "lt": r"sub|mai (?:mic\w*|redus\w*|putin\w*) (?:decat|de)|<",
                        "gt": r"peste|mai (?:mar\w*|mult\w*) (?:decat|de)|depaseste|>",
                        "eq": r"exact|egal\w* cu|="}
            prefix = t[:prag.start()].rstrip()
            comparatie = next((k for k,v in conditii.items()
                               if re.search(r"(?:" + v + r")\s*(?:de)?$", prefix)), None)
            if comparatie is None or re.search(r"\d+(?:[.,]\d+)?\s*%", t[prag.end():]):
                raise ValueError("Specifică un singur prag de prezență, de exemplu «cel puțin 50%».")
            param["comparatie"] = comparatie
        necesare.update(["LT", "Votanti_LP", "Votanti_LS"])
    elif tip == "tabel_ani":
        param["toti"] = ("toti anii" in t or
                         ("in fiecare an" in t and re.search(r"pozitiv|inregistrat|pastreaza|numai", t) is not None))
    elif tip == "total_local":
        param.update(eticheta=eticheta("Total"), indicatori=selectate or indicatori)
    elif tip == "standardizare":
        param["moduri"] = [k for k,v in [("centrare","centr"),("standardizare","standard")] if v in t]
    elif tip == "matrici_statistice":
        param["moduri"] = [k for k,v in [("corelatie","corela"),("covarianta","covarian")] if v in t]
        param["grup"] = (grup or "Regiune") if ("grup" in t or grup) else None
        if param["grup"]:
            necesare.add(param["grup"])
    elif tip == "distante":
        param["moduri"] = [k for k in ("euclid", "mahalanobis") if k in t]
    elif tip in ("inertii", "centri_grupe", "distante_centri"):
        grup = grup or "Regiune"
        cere_grup()
    if "moduri" in param and not param["moduri"]:
        raise ValueError(f"Precizează metoda de calcul: {text}")
    if "MacroRegiune" in necesare:
        necesare.add("Regiune")
    if tip == "raport_local" and "localitat" in t:
        necesare.add("Localitate")
    for f in filtre:
        if f["camp"] == "@rezultat":
            if not param.get("eticheta") or tip == "localitate_extrema" or param.get("separat"):
                raise ValueError("Nu există o singură coloană numerică de rezultat pentru acest prag.")
            f["rezultat"] = param["eticheta"]
    return dict(functie=tip, parametri=param, filtre=filtre, fisier=Path(iesire).stem,
                sortare=sortare, necesare=sorted(necesare))


def planifica(text, indicatori, categorie=None):
    model = ModelCerinte()
    plan = []
    for nr,(enunt, antet) in enumerate(separa(text), 1):
        if re.search(r"\b(mediana|regres\w*|prognoz\w*|predict\w*|percentil\w*|cuantil\w*|grafic\w*)\b", simplifica(enunt)):
            raise ValueError(f"Operație în afara catalogului: {enunt}")
        t = simplifica(enunt)
        # Un raport explicit cu doi operanzi nu depinde de asemănarea cu exemplele de antrenare.
        formula = re.search(r"\braport(?:ul)? (?:dintre|intre)\b", t) or re.search(r"\b\w+\s*/\s*\w+\b", t)
        if formula and not re.search(r"\blocaliz\w*|\b(?:maxim|minim|cel mai|cea mai|medie|median\w*)\b", t):
            tip, scor = "raport_local", None
        else:
            tip, scor = model.recunoaste(enunt)
        pas = interpreteaza(enunt, antet, tip, indicatori, nr, categorie)
        pas.update(enunt=enunt, scor=round(scor, 3) if scor is not None else None)
        plan.append(pas)
    return plan
