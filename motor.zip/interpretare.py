"""Transformă clasa ML și cuvintele cerinței în parametri expliciți."""
import re
from pathlib import Path
from date_intrare import simplifica
from enunturi import ModelCerinte, separa


def campuri_mentionate(text, coloane):
    sinonime = {
        "totalcifraafaceri": r"cifr\w* (?:totala )?de afaceri",
        "nrsal": r"salariat\w*|angajat\w*|angajare|ocupar\w*",
        "nrfirme": r"firm\w*",
        "totalprofit": r"profit\w*",
        "totalpierdere": r"pierder\w*",
        "populatie": r"populati\w*|locuitor\w*|cap de locuitor",
    }
    gasite = []
    echivalente = {
        "cifraafaceri":"totalcifraafaceri", "cifradeafaceri":"totalcifraafaceri",
        "ca":"totalcifraafaceri", "salariati":"nrsal", "angajati":"nrsal",
        "nrangajati":"nrsal", "firme":"nrfirme", "profit":"totalprofit",
        "pierdere":"totalpierdere", "pierderi":"totalpierdere",
    }
    for c in coloane:
        cheie = simplifica(c)
        # «ca» este și conjuncție în română. Înlocuim abrevierea CA înainte de normalizare.
        expresie = r"\b" + re.escape(cheie) + r"\b" if cheie != "ca" else r"(?!)"
        rol = echivalente.get(cheie.replace("_",""), cheie.replace("_",""))
        if rol in sinonime:
            expresie += "|" + sinonime[rol]
        potriviri = list(re.finditer(expresie, text))
        if potriviri:
            gasite.append((potriviri[0].start(), c))
    return [c for _, c in sorted(gasite)]


def interpreteaza(text, antet, tip, indicatori, numar, categorie):
    t = simplifica(re.sub(r"\bCA\b", "cifra de afaceri", text))
    nume_csv = re.findall(r"(?i)([\w-]+\.csv)\b", text)
    iesire = nume_csv[0] if nume_csv else f"Cerinta{numar}.csv"
    if tip == "medii_ponderate" and not nume_csv and "cifra de afaceri" in t:
        iesire = f"Output{numar}.csv"
    param = {}
    necesare = set()
    nivele = [k for k, s in [("Localitate","localitat"), ("Judet","judet"),
              ("Regiune",r"\bregiun"), ("MacroRegiune","macroregiun")] if re.search(s,t)]
    grup = next((n for n in reversed(nivele) if n != "Localitate"), None)
    sortare = "desc" if "descresc" in t else ("asc" if "crescator" in t else "")
    etichete = [x.strip() for x in antet.split(",")] if antet else []
    def eticheta(implicit):
        return etichete[-1] if len(etichete) in (2, 3) else implicit

    def cere_grup():
        if not grup:
            raise ValueError(f"Specifică nivelul (județ, regiune sau macroregiune): {text}")
        param["grup"] = grup
        necesare.add(grup)

    mentionate = campuri_mentionate(t, indicatori + ["Populatie"])
    selectate = [c for c in mentionate if c in indicatori]
    if tip in ("rata_grupata", "raport_local", "localitate_extrema"):
        # Caută numitorul după expresia de împărțire înainte de a aplica ordinea mențiunilor.
        separare = re.search(r"(?:\bpe (?:cap de )?(?=locuitor|salariat)|\bper |\bla (?:\d+ (?:de )?|mia de )?(?=locuitor)|\braportat\w* la |\bimpart\w* la |/)", t)
        numitor = None
        if separare:
            dupa = campuri_mentionate(t[separare.end():], indicatori + ["Populatie"])
            numitor = dupa[0] if dupa else None
        if not numitor and len(mentionate) >= 2:
            numitor = mentionate[1]
        if not numitor and ("populati" in t and tip == "rata_grupata"):
            numitor = "Populatie"
        if not numitor and tip != "localitate_extrema":
            raise ValueError(f"Nu pot identifica numitorul. Scrie explicit coloanele: {text}")
        numarator = [c for c in selectate if c != numitor]
        if not numarator:
            if not re.search(r"activitat|industr|innoptari|toate|totalul indicatorilor", t):
                raise ValueError(f"Nu pot identifica numărătorul: {text}")
            numarator = indicatori
        if numitor:
            necesare.add(numitor)
        param.update(numarator=numarator, numitor=numitor)
        if tip != "raport_local":
            cere_grup()
        if tip == "localitate_extrema":
            param["maxim"] = not re.search(r"minim|mai mic|mai redus|mai putin|mai scazut", t)
            necesare.add("Localitate")
        else:
            baza = re.search(r"\bla\s+([\d. ]+?)\s*(?:de\s+)?locuitor", t)
            factor = int(re.sub(r"\D", "", baza[1])) if baza else 1
            if re.search(r"\b(mia|o mie) de locuitor", t):
                factor = 1000
            if "procent" in t or "%" in t:
                factor = 100
            implicit = "Rata Ocuparii" if "ocupar" in t else "Raport"
            if "cifra de afaceri" in t and numitor == "NrSal":
                implicit = "Raport CA/NrSal"
            elif "cifra de afaceri" in t and numitor == "Populatie":
                implicit = "CA/Loc"
            param.update(factor=factor, eticheta=eticheta(implicit))
            if tip == "rata_grupata":
                param["separat"] = bool(re.search(r"pe fiecare an|pe fiecare activitate", t))
    elif tip == "medii_ponderate":
        cere_grup()
        dupa = re.split(r"folosind ca pondere|ponderat\w* (?:cu|dupa)|ponderi(?:le)? (?:sunt|date de)", t)
        ponderi = campuri_mentionate(dupa[-1], indicatori + ["Populatie"])
        if not ponderi:
            raise ValueError("Precizează ponderea, de exemplu «folosind ca pondere populația».")
        pondere = ponderi[0] if len(dupa) > 1 else ponderi[-1]
        necesare.add(pondere)
        param.update(pondere=pondere, indicatori=[c for c in selectate if c != pondere] or indicatori)
    elif tip in ("medie_grupata", "total_grupat", "indici_localizare", "coeficienti_variatie"):
        cere_grup()
        param["indicatori"] = selectate or indicatori
        if tip == "indici_localizare":
            necesare.add("Populatie")
    elif tip in ("distributii_teritoriale", "diversitate"):
        if not nivele:
            raise ValueError("Precizează nivelurile teritoriale.")
        param["niveluri"] = nivele
        necesare.update(nivele)
        if tip == "distributii_teritoriale":
            param["procente"] = bool(re.search(r"procent|ponder", t))
    elif tip == "segregare":
        cere_grup()
        param["cu_disimilaritate"] = "disimil" in t or "segreg" in t
        if "vot" in t:
            param["indicatori"] = [c for c in indicatori if c.startswith(("Barbati_", "Femei_"))]
    elif tip == "categorie_dominanta":
        param["grup"] = grup
        if grup:
            necesare.add(grup)
        varste = [c for c in indicatori if c.startswith(("Barbati_", "Femei_"))]
        if varste:
            param["indicatori"] = varste
        filtru = next((c for c in varste if simplifica(c) in t), None)
        if "categorie_varsta" in t:
            if not categorie and not filtru:
                raise ValueError("Tema cere o categorie. Specifică, de exemplu, Barbati_35-44.")
            filtru = filtru or categorie
        if filtru and filtru not in varste:
            raise ValueError(f"Categorie indisponibilă: {filtru}. Opțiuni: {varste}")
        if iesire.casefold() == "categorie_varsta.csv":
            iesire = filtru + ".csv"
        param.update(categorie=filtru, omite_zero="omise" in t or "fara activitate" in t,
                     eticheta=eticheta("Categorie" if varste else ("Anul" if "anul" in t else "Activitate")))
        if "anul" in t and not grup:
            necesare.add("Localitate")
    elif tip == "prezenta_vot":
        prag = re.search(r"(\d+(?:[.,]\d+)?)\s*%", t)
        param["prag"] = float(prag[1].replace(",", ".")) if prag else None
        necesare.update(["LT", "Votanti_LP", "Votanti_LS"])
    elif tip == "tabel_ani":
        param["toti"] = "toti anii" in t
    elif tip == "total_local":
        param.update(eticheta=eticheta("Total"), indicatori=selectate or indicatori)
    elif tip == "standardizare":
        param["moduri"] = [k for k,v in [("centrare","centr"),("standardizare","standard")] if v in t]
    elif tip == "matrici_statistice":
        param["moduri"] = [k for k,v in [("corelatie","corela"),("covarianta","covarian")] if v in t]
        param["grup"] = (grup or "Regiune") if ("grup" in t or grup) else None
        if param["grup"]:
            necesare.add(param["grup"])
    elif tip == "distante":
        param["moduri"] = [k for k in ("euclid", "mahalanobis") if k in t]
    elif tip in ("inertii", "centri_grupe", "distante_centri"):
        grup = grup or "Regiune"
        cere_grup()
    if "moduri" in param and not param["moduri"]:
        raise ValueError(f"Precizează metoda de calcul: {text}")
    if "MacroRegiune" in necesare:
        necesare.add("Regiune")
    if tip == "raport_local" and "localitat" in t:
        necesare.add("Localitate")
    return dict(functie=tip, parametri=param, fisier=Path(iesire).stem,
                sortare=sortare, necesare=sorted(necesare))


def planifica(text, indicatori, categorie=None):
    model = ModelCerinte()
    plan = []
    for nr,(enunt, antet) in enumerate(separa(text), 1):
        if re.search(r"\b(mediana|regres\w*|prognoz\w*|predict\w*|percentil\w*|cuantil\w*|grafic\w*)\b", simplifica(enunt)):
            raise ValueError(f"Operație în afara catalogului: {enunt}")
        tip, scor = model.recunoaste(enunt)
        pas = interpreteaza(enunt, antet, tip, indicatori, nr, categorie)
        pas.update(enunt=enunt, scor=round(scor, 3))
        plan.append(pas)
    return plan
