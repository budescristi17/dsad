"""Construiește scriptul autonom pe care îl primește studentul."""
import inspect

import pandas as pd
import numpy as np


def medie_ponderata(df, variabile, pondere):
    ponderi = df[pondere]
    if (ponderi < 0).any():
        raise ValueError("Ponderile trebuie să fie nenegative.")
    if ponderi.sum() == 0:
        return pd.Series(np.nan, index=variabile)
    return pd.Series(np.average(df[variabile], axis=0, weights=ponderi), index=variabile)


def citire_simpla(dosar, principal, auxiliare, plan):
    """Folosește citirea scurtă doar pentru tabele CSV standard cu aceeași cheie."""
    operatii = {"raport_local", "rata_grupata", "localitate_extrema", "medii_ponderate"}
    if len(auxiliare) > 1 or any(p["functie"] not in operatii for p in plan):
        return None
    if any(p["parametri"].get("separat") for p in plan):
        return None
    if len({p["fisier"].casefold() for p in plan}) != len(plan):
        return None
    try:
        t = pd.read_csv(dosar / principal, dtype={"Siruta": str})
        aux = pd.read_csv(dosar / auxiliare[0], dtype={"Siruta": str}) if auxiliare else None
    except (ValueError, UnicodeError):
        return None
    nume = next((c for c in ["DenLocalitate", "Localitate", "City"] if c in t), None)
    if not nume or "Siruta" not in t or t.Siruta.isna().any() or t.Siruta.duplicated().any():
        return None
    coloane = set(t)
    if aux is not None:
        if "Siruta" not in aux or aux.Siruta.duplicated().any() or not t.Siruta.isin(aux.Siruta).all():
            return None
        coloane.update(aux)
    for pas in plan:
        p = pas["parametri"]
        if p.get("grup") and p["grup"] not in coloane:
            return None
        numerice = p.get("numarator", []) + p.get("indicatori", [])
        numerice += [p[k] for k in ("numitor", "pondere") if p.get(k)]
        for c in numerice:
            if c not in coloane:
                return None
            s = t[c] if c in t else aux[c]
            if not pd.api.types.is_numeric_dtype(s) or s.isna().any():
                return None
    return nume


def cod_tabelar(dosar, principal, auxiliare, plan):
    nume = citire_simpla(dosar, principal, auxiliare, plan)
    if not nume:
        return None
    linii = ["from pathlib import Path", "import numpy as np", "import pandas as pd", "",
             "baza = Path(__file__).resolve().parent", "intrare = baza / 'data_in'",
             f"t = pd.read_csv(intrare / {principal!r}, index_col='Siruta', dtype={{'Siruta': str}})"]
    if auxiliare:
        linii += [f"t_pop = pd.read_csv(intrare / {auxiliare[0]!r}, index_col='Siruta', dtype={{'Siruta': str}})",
                  "coloane_noi = [c for c in t_pop if c not in t]",
                  "if not t.index.isin(t_pop.index).all():",
                  "    raise ValueError('Cod Siruta fără corespondent în tabelul auxiliar.')",
                  "t = t.merge(t_pop[coloane_noi], left_index=True, right_index=True, validate='one_to_one')"]
    if any(p["functie"] == "medii_ponderate" for p in plan):
        linii += ["", "", inspect.getsource(medie_ponderata).rstrip()]
    for nr, pas in enumerate(plan, 1):
        p = pas["parametri"]
        num = p.get("numarator", [])
        den = p.get("numitor")
        grup = p.get("grup")
        et = p.get("eticheta")
        v = f"t{nr}"
        def numarator(tabel):
            return f"{tabel}[{num[0]!r}]" if len(num) == 1 else f"{tabel}[{num!r}].sum(axis=1)"
        factor = f" * {p['factor']!r}" if p.get("factor", 1) != 1 else ""
        linii += ["", f"# Cerința {nr}. {pas['enunt']}"]
        if pas["functie"] == "raport_local":
            linii += [f"{v} = t.loc[t[{den!r}] > 0].copy()",
                      f"{v}[{et!r}] = {numarator(v)}{factor} / {v}[{den!r}]",
                      f"{v} = {v}[[{nume!r}, {et!r}]]"]
        elif pas["functie"] == "rata_grupata":
            campuri = list(dict.fromkeys(num + [den]))
            linii += [f"{v} = t.groupby({grup!r})[{campuri!r}].sum()",
                      f"{v}[{et!r}] = {numarator(v)}{factor} / {v}[{den!r}].replace(0, np.nan)",
                      f"{v} = {v}[[{et!r}]]"]
        elif pas["functie"] == "localitate_extrema":
            metoda = "idxmax" if p["maxim"] else "idxmin"
            linii += [f"{v} = t.loc[t[{den!r}] > 0].copy()" if den else f"{v} = t.copy()",
                      f"scor = {numarator(v)}" + (f" / {v}[{den!r}]" if den else ""),
                      f"coduri = scor.groupby({v}[{grup!r}]).{metoda}()",
                      f"{v} = {v}.loc[coduri, [{grup!r}, {nume!r}]].rename(columns={{{nume!r}: 'Localitate'}})"]
        else:
            linii += [f"variabile = {p['indicatori']!r}", f"pondere = {p['pondere']!r}",
                      f"{v} = t.groupby({grup!r})[{list(dict.fromkeys(p['indicatori'] + [p['pondere']]))!r}].apply(",
                      "    medie_ponderata, variabile=variabile, pondere=pondere)"]
        if pas["sortare"]:
            linii.append(f"{v} = {v}.sort_values({et!r}, ascending={pas['sortare']=='asc'}, kind='stable')" if et
                         else f"{v} = {v}.sort_values({v}.columns[-1], ascending={pas['sortare']=='asc'}, kind='stable')")
        fara_index = ", index=False" if pas["functie"] == "localitate_extrema" else ""
        linii.append(f"{v}.to_csv(baza / {pas['fisier'] + '.csv'!r}{fara_index})")
    iesiri = ", ".join(p["fisier"] + ".csv" for p in plan)
    linii += ["", f"print({'Gata: ' + iesiri!r})"]
    return "\n".join(linii) + "\n"


def scrie_solutie(dosar, principal, auxiliare, plan):
    cod = cod_tabelar(dosar / "data_in", principal, auxiliare, plan)
    if cod is None:
        functii = (dosar / "functii.py").read_text(encoding="utf-8")
        main = (dosar / "main.py").read_text(encoding="utf-8").splitlines()
        program = [linie for linie in main if not linie.startswith("from functii import ")]
        program[program.index('iesiri = baza / "data_out"')] = "iesiri = baza"
        cod = functii + "\n\n" + "\n".join(program) + "\n"
    (dosar / "solutie.py").write_text(cod, encoding="utf-8")
