"""Construiește scriptul autonom pe care îl primește studentul."""
from operator import eq, ge, gt, le, lt, ne

import pandas as pd


def citire_simpla(dosar, principal, auxiliare, plan):
    """Folosește citirea scurtă doar pentru tabele CSV standard cu aceeași cheie."""
    operatii = {"raport_local", "rata_grupata", "localitate_extrema", "medii_ponderate", "total_grupat", "medie_grupata", "total_local"}
    if len(auxiliare) > 1 or any(p["functie"] not in operatii for p in plan):
        return None
    if any(p["parametri"].get("separat") for p in plan):
        return None
    if len({p["fisier"].casefold() for p in plan}) != len(plan):
        return None
    try:
        t = pd.read_csv(dosar / principal, dtype={"Siruta": str})
        aux = pd.read_csv(dosar / auxiliare[0], dtype={"Siruta": str}) if auxiliare else None
    except (ValueError, UnicodeError):
        return None
    nume = next((c for c in ["DenLocalitate", "Localitate", "City"] if c in t), None)
    if not nume or "Siruta" not in t or t.Siruta.isna().any() or t.Siruta.duplicated().any():
        return None
    coloane = set(t)
    if aux is not None:
        if "Siruta" not in aux or aux.Siruta.duplicated().any() or not t.Siruta.isin(aux.Siruta).all():
            return None
        coloane.update(aux)
    for pas in plan:
        p = pas["parametri"]
        if p.get("grup") and p["grup"] not in coloane:
            return None
        numerice = p.get("numarator", []) + p.get("indicatori", [])
        numerice += [p[k] for k in ("numitor", "pondere") if p.get(k)]
        numerice += [f["camp"] for f in pas.get("filtre", []) if "rezultat" not in f]
        for c in numerice:
            if c not in coloane:
                return None
            s = t[c] if c in t else aux[c]
            if not pd.api.types.is_numeric_dtype(s) or s.isna().any():
                return None
    auxiliare_noi = [c for c in aux if c not in t] if aux is not None else []
    return nume, auxiliare_noi, t, aux


def cod_tabelar(dosar, principal, auxiliare, plan):
    schema = citire_simpla(dosar, principal, auxiliare, plan)
    if not schema:
        return None
    nume, noi, tabel, aux = schema
    # Păstrăm cheia ca text când există zerouri inițiale în oricare tabel.
    tip_cheie = ", dtype={'Siruta': str}" if any(df.Siruta.str.match(r"^0[0-9]").any()
                  for df in (tabel,aux) if df is not None) else ""
    def citire(fisier, df):
        cheie = "index_col=0" if df.columns[0] == "Siruta" else "index_col='Siruta'"
        return f"pd.read_csv({'data_in/' + fisier!r}, {cheie}{tip_cheie})"
    baza = {"i2014.csv":"t_firme", "biblioteci.csv":"t_biblioteci"}.get(principal.lower(), "t_date")
    linii = ["import os", "import pandas as pd"]
    if any(p["functie"] == "medii_ponderate" for p in plan):
        linii.append("import numpy as np")
    linii += ["", "os.makedirs('data_out', exist_ok=True)", f"{baza} = {citire(principal,tabel)}"]
    src_initial = baza
    baza_intacta = True
    for nr, pas in enumerate(plan, 1):
        p = pas["parametri"]
        tip = pas["functie"]
        den, grup, et = p.get("numitor"), p.get("grup"), p.get("eticheta")
        num = p.get("numarator", [])
        def numarator(df):
            return f"{df}[{num[0]!r}]" if len(num) == 1 else f"{df}[{num!r}].sum(axis=1)"
        v = f"t{nr}"
        titluri = {"raport_local":"Raport pe localitate", "rata_grupata":"Raport pe grup",
                   "medii_ponderate":"Medii ponderate", "medie_grupata":"Medii pe grup",
                   "total_grupat":"Totaluri pe grup", "total_local":"Total pe localitate",
                   "localitate_extrema":"Localitatea cu valoarea " + ("maximă" if p.get("maxim") else "minimă")}
        necesare = set(pas["necesare"]) | set(p.get("indicatori", []))
        if src_initial == baza and necesare.intersection(noi):
            operand = "t_pop" if len(noi) + 1 == len(aux.columns) else f"t_pop[{noi!r}]"
            linii += ["", "# Legăm tabelele după Siruta.", f"t_pop = {citire(auxiliare[0],aux)}",
                      f"t = {baza}.merge({operand}, left_index=True, right_index=True)"]
            src_initial = "t"
        linii += ["", f"# Cerința {nr}: {titluri[tip]}"]
        src = src_initial
        filtre = [f for f in pas.get("filtre", []) if "rezultat" not in f]
        if den:
            divizori = tabel[den] if den in tabel else aux[den]
            if tip in {"localitate_extrema","raport_local"} and divizori.eq(0).any():
                compara = {"==":eq,"!=":ne,">":gt,">=":ge,"<":lt,"<=":le}
                if not any(f["camp"] == den and not compara[f["op"]](0,f["prag"]) for f in filtre):
                    filtre.append(dict(camp=den, op="!=", prag=0))
        for f in filtre:
            prag = f["prag"]
            prag = int(prag) if int(prag) == prag else prag
            linii.append(f"{v} = {src}[{src}[{f['camp']!r}] {f['op']} {prag!r}].copy()")
            src = v
        factor = f" * {p['factor']}" if p.get("factor", 1) != 1 else ""
        if tip in {"raport_local", "total_local"}:
            if src != v:
                linii.append(f"{v} = {src}.copy()")
            formula = f"{numarator(v)}{factor} / {v}[{den!r}]" if den else f"{v}[{p['indicatori']!r}].sum(axis=1)"
            linii += [f"{v}[{et!r}] = {formula}", f"{v} = {v}[[{nume!r}, {et!r}]]"]
        elif tip == "rata_grupata":
            campuri = list(dict.fromkeys(num + [den]))
            div = f"{v}[{den!r}]" if divizori.gt(0).all() else f"{v}[{den!r}].replace(0, float('nan'))"
            linii += [f"{v} = {src}.groupby({grup!r})[{campuri!r}].sum()",
                      f"{v}[{et!r}] = {numarator(v)}{factor} / {div}", f"{v} = {v}[[{et!r}]]"]
        elif tip == "localitate_extrema":
            metoda = "idxmax" if p["maxim"] else "idxmin"
            randuri = "siruta_max" if p["maxim"] else "siruta_min"
            scor = (num[0].removeprefix("Total")+"PeLocuitor" if len(num)==1 and den=="Populatie" else "ValoareCalculata")
            while scor in tabel.columns or scor in noi:
                scor += "_"
            if src == baza:
                baza_intacta = False
            linii += [f"{src}[{scor!r}] = {numarator(src)}" + (f" / {src}[{den!r}]" if den else ""),
                      f"{randuri} = {src}.groupby({grup!r})[{scor!r}].{metoda}()",
                      f"{v} = {src}.loc[{randuri}, [{grup!r}, {nume!r}]]"]
            if nume != "Localitate":
                linii[-1] += f".rename(columns={{{nume!r}: 'Localitate'}})"
        elif tip == "medii_ponderate":
            w = p["pondere"]
            valori = tabel[w] if w in tabel else aux[w]
            if (valori < 0).any():
                return None
            lista = (f"list({baza}.columns)[1:]" if baza_intacta and list(tabel.drop(columns="Siruta").columns) == [nume] + p["indicatori"]
                     else repr(p["indicatori"]))
            linii += [f"variabile = {lista}", "", "def medie_ponderata(df):"]
            if not valori.gt(0).all():
                linii += [f"    if df[{w!r}].sum() == 0:", "        return pd.Series(np.nan, index=variabile)"]
            linii += [f"    medii = np.average(df[variabile], axis=0, weights=df[{w!r}])",
                      "    return pd.Series(medii, index=variabile)", "",
                      f"{v} = {src}.groupby({grup!r})[variabile + [{w!r}]].apply(medie_ponderata)"]
        else:
            metoda = "sum" if tip == "total_grupat" else "mean"
            linii.append(f"{v} = {src}.groupby({grup!r})[{p['indicatori']!r}].{metoda}()")
        for f in pas.get("filtre", []):
            if "rezultat" in f:
                linii.append(f"{v} = {v}.loc[{v}[{f['rezultat']!r}] {f['op']} {f['prag']!r}]")
        if pas["sortare"]:
            col = repr(et) if et else f"{v}.columns[-1]"
            order = ", ascending=False" if pas["sortare"] == "desc" else ""
            linii.append(f"{v} = {v}.sort_values({col}{order}, kind='stable')")
        index = ", index=False" if tip == "localitate_extrema" else ""
        linii.append(f"{v}.to_csv({'data_out/' + pas['fisier'] + '.csv'!r}{index})")
    return "\n".join(linii) + "\n"
