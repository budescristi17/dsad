"""Segmentare și clasificare locală TF-IDF / cel mai apropiat exemplu."""
from pathlib import Path
import json
import re
from io import BytesIO
from zipfile import ZipFile
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import FeatureUnion
from sklearn.preprocessing import normalize
from date_intrare import simplifica


def citeste_enunt(cale):
    cale = Path(cale)
    if cale.suffix.lower() == ".pdf":
        from pypdf import PdfReader
        text = "\n".join(p.extract_text() or "" for p in PdfReader(cale).pages)
        if not text.strip():
            raise ValueError("PDF fără strat de text. Introdu manual cerințele.")
        return text
    return cale.read_text(encoding="utf-8-sig")


def enunt_din_proiect(sursa):
    sursa = Path(sursa)
    if sursa.is_dir():
        baza = sursa.parent if sursa.name.lower() == "data_in" else sursa
        fisiere = sorted(baza.glob("Tema*.pdf"))
        if len(fisiere) == 1:
            return citeste_enunt(fisiere[0])
    elif sursa.suffix.lower() == ".zip" and sursa.is_file():
        from pypdf import PdfReader
        with ZipFile(sursa) as z:
            fise = [n for n in z.namelist() if re.search(r"(?:^|[/\\])Tema[^/\\]*\.pdf$", n, re.I)]
            if len(fise) == 1:
                return "\n".join(p.extract_text() or "" for p in PdfReader(BytesIO(z.read(fise[0]))).pages)
    return ""


def separa(text):
    text = text.replace("\r", "")
    parti = re.split(r"(?im)^\s*(?:(?:cerin[țt]a\s+)?\d{1,2}[.):]|[-•])\s+(?=[^\d\s])", text)
    if len(parti) > 1:
        parti = parti[1:]
    cerinte = []
    for parte in parti:
        parte = re.split(r"(?im)^\s*(?:indica[țt]ie|observa[țt]ie|1 punct din oficiu)\s*$", parte)[0]
        enunt, *exemple = re.split(r"(?im)^\s*exemplu\s*:?\s*(?:\n|$)", parte, maxsplit=1)
        antet = exemple[0].strip().splitlines()[0] if exemple and exemple[0].strip() else ""
        enunt = " ".join(enunt.split())
        if enunt:
            cerinte.append((enunt, antet.strip()))
    if not cerinte:
        raise ValueError("Introdu cel puțin o cerință.")
    return cerinte


def cuvinte(text):
    text = re.sub(r"[\w.-]+\.csv\b|\(\d+ puncte?\)", " ", simplifica(text))
    text = re.sub(r"\b(sa se|si sa se|in fisierul|pentru fiecare|se va|se vor)\b", " ", text)
    return " ".join(re.findall(r"[a-z0-9_]+", text))


class ModelCerinte:
    def __init__(self):
        cale = Path(__file__).with_name("exemple.json")
        self.exemple = json.loads(cale.read_text(encoding="utf-8"))
        self.vectori = FeatureUnion([
            ("cuvinte", TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True)),
            ("fragmente", TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), sublinear_tf=True)),
        ])
        self.matrice = normalize(self.vectori.fit_transform([cuvinte(e[1]) for e in self.exemple]))

    def recunoaste(self, text):
        vector = normalize(self.vectori.transform([cuvinte(text)]))
        scoruri = (self.matrice @ vector.T).toarray().ravel()
        ordonate = np.argsort(-scoruri, kind="stable")
        i = ordonate[0]
        tip, exemplu = self.exemple[i]
        j = next(j for j in ordonate if self.exemple[j][0] != tip)
        if scoruri[i] < 0.28 or scoruri[i] - scoruri[j] < 0.035:
            raise ValueError(f"Cerință necunoscută sau ambiguă: {text}\n"
                             f"Interpretări apropiate: {tip}, {self.exemple[j][0]}. "
                             "Reformulează cu operația, coloanele și nivelul geografic.")
        return tip, float(scoruri[i])
