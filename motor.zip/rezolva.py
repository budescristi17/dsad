"""Generatorul local de proiecte DSAD. Fără argumente deschide interfața grafică."""
import argparse
import ast
import inspect
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import sys
import tempfile
from zipfile import ZipFile

import operatii
from cod_complet import cod_tabelar
from date_intrare import citeste_csv, coloana, pregateste_date, simplifica
from enunturi import citeste_enunt, enunt_din_proiect
from interpretare import planifica
from control import verifica_date, verifica_rezultate

RADACINA = Path(__file__).resolve().parent


def nume_sigur(nume):
    if (not nume or re.search(r'[<>:"/\\|?*\x00-\x1f]', nume) or nume.endswith((" ", "."))
            or (hasattr(os.path, "isreserved") and os.path.isreserved(nume))):
        raise ValueError(f"Nume de fișier nepermis: {nume!r}")
    return nume


def copiaza_date(sursa, dosar):
    sursa = Path(sursa).resolve()
    if not sursa.exists():
        raise ValueError(f"Sursa nu există: {sursa}")
    dosar.mkdir()
    if sursa.suffix.lower() == ".zip" and sursa.is_file():
        with ZipFile(sursa) as arhiva:
            fisiere = [(n, PurePosixPath(n.replace("\\", "/"))) for n in arhiva.namelist()]
            fisiere = [(n,p) for n,p in fisiere if p.suffix.lower() == ".csv" and
                       not {"data_out","__macosx"}.intersection(s.lower() for s in p.parts)]
            seminar = [(n,p) for n,p in fisiere if "data_in" in [s.lower() for s in p.parts]]
            for n,p in seminar or fisiere:
                with (dosar / nume_sigur(p.name)).open("xb") as destinatie, arhiva.open(n) as f:
                    shutil.copyfileobj(f, destinatie)
    else:
        if sursa.is_dir():
            baza = sursa / "data_in" if (sursa / "data_in").is_dir() else sursa
            fisiere = list(baza.glob("*.csv"))
        else:
            fisiere = [sursa] if sursa.suffix.lower() == ".csv" else []
        for f in fisiere:
            shutil.copyfile(f, dosar / f.name)
    if not any(dosar.iterdir()):
        raise ValueError("Sursa trebuie să conțină CSV-uri direct sau în data_in.")


def alege_fisiere(dosar, cerut):
    ordine = {}
    principale = []
    for f in sorted(dosar.glob("*.csv")):
        tabel = citeste_csv(f)
        coloane = {simplifica(c) for c in tabel}
        metadate = {"siruta","codsiruta","code","city","denlocalitate","localitate","judet",
                    "county","populatie","nrcrt","indicativjudet","numejudet","regiune","macroregiune"}
        if coloane - metadate:
            principale.append(f.name)
        elif coloana(tabel, ["Siruta", "Code", "CodSiruta"]):
            ordine[f.name] = 1
        elif coloana(tabel, ["IndicativJudet", "Judet"]):
            ordine[f.name] = 2
        else:
            ordine[f.name] = 3
    if cerut:
        if not (dosar / nume_sigur(cerut)).is_file():
            raise ValueError(f"Nu există fișierul principal {cerut} în datele selectate.")
        principal = cerut
    elif len(principale) == 1:
        principal = principale[0]
    else:
        raise ValueError(f"Alege un singur tabel de indicatori sau specifică fișierul principal. Candidați: {principale}")
    return principal, sorted((f for f in ordine if f != principal), key=ordine.get)


def descrie(plan):
    linii = []
    for i,p in enumerate(plan, 1):
        param = ", ".join(f"{k}={v!r}" for k,v in p["parametri"].items())
        sortare = f", sortare={p['sortare']}" if p["sortare"] else ""
        metoda = "formulă explicită" if p["scor"] is None else f"similaritate {p['scor']:.2f}"
        linii.append(f"{i}. {p['functie']}({param}) → {p['fisier']}{sortare}  [{metoda}]")
    return "\n".join(linii)


def functii_selectate(plan):
    sursa = RADACINA.joinpath("operatii.py").read_text(encoding="utf-8")
    arbore = ast.parse(sursa)
    functii = {n.name:n for n in arbore.body if isinstance(n, ast.FunctionDef)}
    alese = set()
    def adauga(nume):
        if nume in alese:
            return
        alese.add(nume)
        for nod in ast.walk(functii[nume]):
            if isinstance(nod, ast.Name) and nod.id in functii:
                adauga(nod.id)
    for p in plan:
        adauga(p["functie"])
    bucati = [ast.get_source_segment(sursa,n) for n in arbore.body
              if isinstance(n,(ast.Import, ast.ImportFrom)) or getattr(n,"name",None) in alese]
    return "\n\n".join(bucati)


def retine_rezultat(rezultate, nume, tabel):
    """Un singur CSV pe cerință sau câte un CSV pentru fiecare nivel / matrice."""
    tabele = tabel if isinstance(tabel, dict) else {"": tabel}
    for sufix, parte in tabele.items():
        cheie = f"{nume}_{sufix}" if len(tabele) > 1 else nume
        if cheie in rezultate:
            raise ValueError(f"Ieșire repetată: {cheie}")
        if "/" in cheie or "\\" in cheie or ":" in cheie:
            raise ValueError(f"Nume de ieșire nepermis: {cheie}")
        rezultate[cheie] = parte


def scrie_proiect(dosar, principal, auxiliare, plan):
    verifica_date(dosar / "data_in", principal, auxiliare, plan)
    cod = cod_tabelar(dosar / "data_in", principal, auxiliare, plan)
    if cod is not None:
        (dosar / "main.py").write_text(cod, encoding="utf-8")
        return
    pregatire = (RADACINA / "date_intrare.py").read_text(encoding="utf-8")
    necesare = sorted(set().union(*(p["necesare"] for p in plan)))
    linii = [pregatire, functii_selectate(plan), inspect.getsource(retine_rezultat),
             "", "baza = Path(__file__).resolve().parent", 'iesiri = baza / "data_out"',
             "iesiri.mkdir(exist_ok=True)", "rezultate = {}",
             f"date, indicatori, nume = pregateste_date(baza / 'data_in', {principal!r}, {auxiliare!r}, {necesare!r})", ""]
    for nr,p in enumerate(plan,1):
        functie = getattr(operatii,p["functie"])
        param = p["parametri"]
        valori = {"df":"date", "indicatori":"indicatori", "nume":"nume"}
        valori.update({k:repr(v) for k,v in param.items()})
        linii.append(f"# Cerința {nr}: {p['enunt']}")
        for f in p.get("filtre", []):
            if "rezultat" not in f:
                sursa = valori["df"]
                linii.append(f"selectie = {sursa}.loc[{sursa}[{f['camp']!r}] {f['op']} {f['prag']!r}]")
                valori["df"] = "selectie"
        args = ", ".join(f"{k}={valori[k]}" for k in inspect.signature(functie).parameters)
        linii.append(f"tabel = {p['functie']}({args})")
        for f in p.get("filtre", []):
            if "rezultat" in f:
                linii.append(f"tabel = tabel.loc[tabel[{f['rezultat']!r}] {f['op']} {f['prag']!r}]")
        if p["sortare"]:
            linii.append(f"tabel = tabel.sort_values(tabel.columns[-1], ascending={p['sortare']=='asc'}, kind='stable')")
        baza = p["fisier"]
        linii.extend([f"retine_rezultat(rezultate, {baza!r}, tabel)", ""])
    precizii = {p["fisier"]: f"%.{p['zecimale']}f" for p in plan if p.get("zecimale") is not None}
    linii.extend([f"formate = {precizii!r}", "for nume_fisier, tabel in rezultate.items():",
                  "    tabel.to_csv(iesiri / (nume_fisier + '.csv'), float_format=formate.get(nume_fisier))",
                  "    print(nume_fisier + '.csv', len(tabel), 'rânduri')"])
    (dosar / "main.py").write_text("\n".join(linii) + "\n", encoding="utf-8")


def genereaza(text, sursa, destinatie, principal=None, categorie=None, confirma=None):
    import subprocess
    destinatie = Path(destinatie).resolve()
    if destinatie.exists():
        raise ValueError(f"Destinația există deja. Alege un dosar nou: {destinatie}")
    destinatie.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=destinatie.parent) as temporar:
        dosar = Path(temporar) / "proiect"
        dosar.mkdir()
        intrari = dosar / "data_in"
        copiaza_date(sursa, intrari)
        principal, auxiliare = alege_fisiere(intrari, principal)
        _, indicatori, _ = pregateste_date(intrari, principal, [], [])
        plan = planifica(text, indicatori, categorie)
        rezumat = f"Tabel principal: {principal}\n" + descrie(plan)
        if confirma and not confirma(rezumat):
            return None
        scrie_proiect(dosar, principal, auxiliare, plan)
        proces = subprocess.run([sys.executable, "-B", str(dosar/"main.py")], cwd=dosar, capture_output=True,
                                encoding="utf-8", env={**os.environ,"PYTHONIOENCODING":"utf-8"})
        if proces.returncode:
            raise ValueError(proces.stderr.strip().splitlines()[-1])
        verifica_rezultate(intrari, principal, auxiliare, plan, dosar / "data_out")
        dosar.rename(destinatie)
        return rezumat + "\n\n" + proces.stdout


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--date", help="Dosar, arhivă ZIP sau un singur CSV")
    parser.add_argument("--enunt", help="Fișier .txt sau .pdf cu enunțurile")
    parser.add_argument("--text", help="Cerința introdusă direct")
    parser.add_argument("--iesire", help="Numele unui proiect nou")
    parser.add_argument("--principal", help="Numele CSV-ului principal, dacă sunt mai multe")
    parser.add_argument("--categorie", help="Categoria pentru Tema2_3, de exemplu Barbati_35-44")
    args = parser.parse_args()
    if len(sys.argv) == 1:
        from interfata import porneste
        porneste()
        return
    if not args.date or not args.iesire or (args.text and args.enunt):
        parser.error("Specifică --date și --iesire. Alege cel mult una dintre --text și --enunt.")
    try:
        text = args.text or (citeste_enunt(args.enunt) if args.enunt else enunt_din_proiect(args.date))
        if not text:
            raise ValueError("Proiectul nu are o singură fișă Tema PDF lizibilă. Specifică --enunt sau --text.")
        print(genereaza(text, args.date, args.iesire,
                        args.principal, args.categorie))
    except (ValueError, OSError, KeyError) as exc:
        parser.exit(1, f"Eroare: {exc}\n")


if __name__ == "__main__":
    main()
