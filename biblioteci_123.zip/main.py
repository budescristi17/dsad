import os
import pandas as pd

os.makedirs('data_out', exist_ok=True)
biblioteci = pd.read_csv('data_in/Biblioteci.csv')

# Cerința 1: Raport pe localitate
conditie = biblioteci['CititoriActivi'] >= 1
rezultat = biblioteci.loc[conditie].copy()
rezultat['Imprumuturi/Cititor'] = rezultat['Imprumuturi'] / rezultat['CititoriActivi']
rezultat = rezultat[['Siruta', 'DenLocalitate', 'Imprumuturi/Cititor']]
rezultat = rezultat.sort_values('Imprumuturi/Cititor', ascending=False, kind='stable')
rezultat.to_csv('data_out/Output1.csv', index=False)

# Cerința 2: Raport pe grup
populatie = pd.read_csv('data_in/PopulatieBiblioteci.csv')
date = biblioteci.merge(populatie, on='Siruta')
total = date.groupby('Judet')[['CititoriActivi', 'Populatie']].sum()
total['Cititori la mie'] = total['CititoriActivi'] / total['Populatie'] * 1000
rez2 = total[['Cititori la mie']]
rez2 = rez2.sort_values('Cititori la mie', ascending=False, kind='stable')
rez2.to_csv('data_out/Output2.csv', float_format='%.2f')

# Cerința 3: Localitatea cu valoarea maximă
date['ImprumuturiPeLocuitor'] = date['Imprumuturi'] / date['Populatie']
maxim = date.groupby('Judet')['ImprumuturiPeLocuitor'].idxmax()
rez3 = date.loc[maxim, ['Judet', 'DenLocalitate']]
rez3 = rez3.rename(columns={'DenLocalitate': 'Localitate'})
rez3.to_csv('data_out/Output3.csv', index=False)
